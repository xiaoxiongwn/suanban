package com.example.dutyscheduler;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerPattern;
    private TextView tvStartDate, tvQueryDate, tvResult;

    private Calendar startDateCalendar;
    private Calendar queryDateCalendar;

    private int workDays = 1;
    private int restDays = 2;
    private int period = workDays + restDays;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerPattern = findViewById(R.id.spinner_pattern);
        tvStartDate = findViewById(R.id.tv_start_date);
        tvQueryDate = findViewById(R.id.tv_query_date);
        tvResult = findViewById(R.id.tv_result);

        startDateCalendar = getClearCalendar();
        queryDateCalendar = getClearCalendar();

        updateDateDisplay();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.duty_patterns, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPattern.setAdapter(adapter);

        spinnerPattern.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateRestDaysByPattern(position);
                updateResult();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        tvStartDate.setOnClickListener(v -> showDatePickerDialog(true));
        tvQueryDate.setOnClickListener(v -> showDatePickerDialog(false));

        updateResult();
    }

    private void updateRestDaysByPattern(int position) {
        switch (position) {
            case 0: restDays = 2; break;
            case 1: restDays = 3; break;
            case 2: restDays = 4; break;
            default: restDays = 2;
        }
        period = workDays + restDays;
    }

    private void showDatePickerDialog(boolean isStartDate) {
        Calendar currentCalendar = isStartDate ? startDateCalendar : queryDateCalendar;
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    Calendar newCalendar = getClearCalendar();
                    newCalendar.set(year, month, dayOfMonth);
                    if (isStartDate) startDateCalendar = newCalendar;
                    else queryDateCalendar = newCalendar;
                    updateDateDisplay();
                    updateResult();
                }, currentCalendar.get(Calendar.YEAR),
                currentCalendar.get(Calendar.MONTH),
                currentCalendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void updateDateDisplay() {
        tvStartDate.setText(dateFormat.format(startDateCalendar.getTime()));
        tvQueryDate.setText(dateFormat.format(queryDateCalendar.getTime()));
    }

    private void updateResult() {
        long diffMillis = queryDateCalendar.getTimeInMillis() - startDateCalendar.getTimeInMillis();
        long diffDays = diffMillis / (24 * 60 * 60 * 1000);
        long offset = ((diffDays % period) + period) % period;
        boolean isWorkDay = offset < workDays;
        tvResult.setText(isWorkDay ? "上班" : "休息");
    }

    private Calendar getClearCalendar() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar;
    }

    public void onCalculateClick(View view) {
        updateResult();
    }
}
